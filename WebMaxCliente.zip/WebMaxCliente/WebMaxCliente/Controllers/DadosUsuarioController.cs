﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PdfSharpCore.Drawing;
using QRCoder;
using WebMaxCliente.Models;

namespace WebMaxCliente.Controllers
{
    public class DadosUsuarioController : Controller
    {
        private readonly ContextoData _context;
        private IHostingEnvironment _environment;

        public DadosUsuarioController(ContextoData context, IHostingEnvironment hostingEnvironment)
        {
            _context = context;
            _environment = hostingEnvironment;
        }

        // GET: DadosUsuario
        public async Task<IActionResult> Index()
        {
            return View(await _context.DadosUsuarioViewModel.ToListAsync());
        }

        // GET: DadosUsuario/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dadosUsuarioViewModel = await _context.DadosUsuarioViewModel
                .FirstOrDefaultAsync(m => m.Id == id);
            if (dadosUsuarioViewModel == null)
            {
                return NotFound();
            }

            await GeraQrCode(dadosUsuarioViewModel);

            return View(dadosUsuarioViewModel);
        }

        // GET: DadosUsuario/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: DadosUsuario/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Nome,CPF,RG,Endereco,Email,Telefone,Idade")] DadosUsuarioViewModel dadosUsuarioViewModel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(dadosUsuarioViewModel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(dadosUsuarioViewModel);
        }

        // GET: DadosUsuario/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dadosUsuarioViewModel = await _context.DadosUsuarioViewModel.FindAsync(id);
            if (dadosUsuarioViewModel == null)
            {
                return NotFound();
            }

            await GeraQrCode(dadosUsuarioViewModel);

            return View(dadosUsuarioViewModel);
        }

        // POST: DadosUsuario/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Nome,CPF,RG,Endereco,Email,Telefone,Idade")] DadosUsuarioViewModel dadosUsuarioViewModel)
        {
            if (id != dadosUsuarioViewModel.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(dadosUsuarioViewModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DadosUsuarioViewModelExists(dadosUsuarioViewModel.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(dadosUsuarioViewModel);
        }

        // GET: DadosUsuario/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dadosUsuarioViewModel = await _context.DadosUsuarioViewModel
                .FirstOrDefaultAsync(m => m.Id == id);
            if (dadosUsuarioViewModel == null)
            {
                return NotFound();
            }

            return View(dadosUsuarioViewModel);
        }

        // POST: DadosUsuario/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var dadosUsuarioViewModel = await _context.DadosUsuarioViewModel.FindAsync(id);
            _context.DadosUsuarioViewModel.Remove(dadosUsuarioViewModel);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DadosUsuarioViewModelExists(int id)
        {
            return _context.DadosUsuarioViewModel.Any(e => e.Id == id);
        }


        private async Task<byte[]> GeraQrCode(DadosUsuarioViewModel dadosUsuarioViewModel)
        {
            QRCodeGenerator qrCodeGenerator = new QRCodeGenerator();

            var dados = Help.ZipObjToBase64(dadosUsuarioViewModel);

            QRCodeData qrCodeData = qrCodeGenerator.CreateQrCode(dados, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(20);
            var bitmapBytes = BitmapToBytes(qrCodeImage);

            ViewBag.image = string.Concat("data:image/jpg;base64,", Convert.ToBase64String(bitmapBytes));

            return bitmapBytes;
        }

        private static byte[] BitmapToBytes(Bitmap img)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                img.Save(stream, System.Drawing.Imaging.ImageFormat.Png);

                return stream.ToArray();
            }
        }




        public async Task<FileResult> Download(int id)
        {


            var dadosUsuarioViewModel = await _context.DadosUsuarioViewModel.SingleOrDefaultAsync(m => m.Id == id);



            using (var doc = new PdfSharpCore.Pdf.PdfDocument())
            {

                #region Configuracoes da folha
                var page = doc.AddPage();

                page.Size = PdfSharpCore.PageSize.A4;
                page.Orientation = PdfSharpCore.PageOrientation.Portrait;

                var graphics = XGraphics.FromPdfPage(page);
                var corFonte = XBrushes.Black;
                #endregion

                #region Numeração das Páginas
                int qtdPaginas = doc.PageCount;

                var numeracaoPagina = new PdfSharpCore.Drawing.Layout.XTextFormatter(graphics);

                numeracaoPagina.DrawString(Convert.ToString(qtdPaginas), new PdfSharpCore.Drawing.XFont("Arial", 10), corFonte, new PdfSharpCore.Drawing.XRect(575, 825, page.Width, page.Height));
                #endregion

                #region Logo 
                var webRoot = _environment.WebRootPath;

                var logoFatura = string.Concat(webRoot, "/img/", "transferir.png");

                XImage imagem = XImage.FromFile(logoFatura);

                graphics.DrawImage(imagem, 20, 5, 300, 50);
                #endregion

                #region Informações 1
                var relatorioCobranca = new PdfSharpCore.Drawing.Layout.XTextFormatter(graphics);

                var titulo = new PdfSharpCore.Drawing.XFont("Arial", 14, PdfSharpCore.Drawing.XFontStyle.Bold);

                relatorioCobranca.Alignment = PdfSharpCore.Drawing.Layout.XParagraphAlignment.Center;

                relatorioCobranca.DrawString("CADASTRO OFFLINE", titulo, corFonte, new XRect(0, 65, page.Width, page.Height));


                #endregion

                #region Informações 2
                var alturaTituloDetalhesY = 120;

                var detalhes = new PdfSharpCore.Drawing.Layout.XTextFormatter(graphics);

                var tituloInfo_1 = new PdfSharpCore.Drawing.XFont("Arial", 8, XFontStyle.Regular);

                var DataAtual = DateTime.Now;
                CultureInfo cult = new CultureInfo("pt-BR");
                string dataatual = DataAtual.ToString("dd/MM/yyyy HH:mm:ss", cult);

                detalhes.DrawString("Data Atual:", tituloInfo_1, corFonte, new XRect(25, alturaTituloDetalhesY, page.Width, page.Height));
                detalhes.DrawString(dataatual, tituloInfo_1, corFonte, new XRect(150, alturaTituloDetalhesY, page.Width, page.Height));

                detalhes.DrawString("Usuário:", tituloInfo_1, corFonte, new XRect(25, alturaTituloDetalhesY + 9, page.Width, page.Height));
                detalhes.DrawString(dadosUsuarioViewModel.Nome, tituloInfo_1, corFonte, new XRect(150, alturaTituloDetalhesY + 9, page.Width, page.Height));


                var tituloInfo_2 = new PdfSharpCore.Drawing.XFont("Arial", 8, XFontStyle.Bold);


                try
                {
                    var img = await GeraQrCode(dadosUsuarioViewModel);

                    Stream streamImage = new MemoryStream(img);

                    XImage qrCode = XImage.FromStream(() => streamImage);

                    alturaTituloDetalhesY += 40;
                    graphics.DrawImage(qrCode, 140, alturaTituloDetalhesY, 310, 310);
                }
                catch (Exception erro)
                {

                }


                alturaTituloDetalhesY += 320;
                detalhes.DrawString("Canhoto com QrCode para integração offline dos dados de cadastro de usuário.", tituloInfo_2, corFonte, new XRect(20, alturaTituloDetalhesY, page.Width, page.Height));

                #endregion


                using (MemoryStream stream = new MemoryStream())
                {
                    var contentType = "application/pdf";

                    doc.Save(stream, false);
                    return File(stream.ToArray(), contentType, "DadosUsuario.pdf");
                }
            }


        }

    }
}
