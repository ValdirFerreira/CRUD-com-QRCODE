﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WebMaxCliente.Models
{
    public static class Help
    {
        /// <summary>
        /// Converte um objeto para Json, o compacta e depois converte para Base64
        /// </summary>
        /// <param name="o">objeto</param>
        /// <returns>string formato base64</returns>
        public static string ZipObjToBase64(Object o)
        {
            string json = Newtonsoft.Json.JsonConvert.SerializeObject(o);
            byte[] dados = Zip(json);
            return ByteToBase64(dados);
        }



        /// <summary>
        /// Zipa uma string
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static byte[] Zip(string str)
        {
            var bytes = Encoding.UTF8.GetBytes(str);

            using (var msi = new MemoryStream(bytes))
            using (var mso = new MemoryStream())
            {
                using (var gs = new GZipStream(mso, CompressionMode.Compress))
                {
                    msi.CopyTo(gs);
                }

                return mso.ToArray();
            }
        }



        public static string ByteToBase64(byte[] dados)
        {
            return Convert.ToBase64String(dados);
        }





        /// <summary>
        /// Descompata uma string no formato base64 devolvendo-o objeto
        /// </summary>
        /// <typeparam name="T">tipo do objeto</typeparam>
        /// <param name="base64Str">string no formato base64</param>
        /// <returns>objeto descompactado</returns>
        public static T UnzipObjFromBase64<T>(string base64Str)
        {
            T obj = default(T);
            bool execucaoComSucesso = false;
            int tentativas = 0;
            do
            {
                try
                {
                    byte[] dados = Base64ToByte(base64Str);
                    string unzipStr = Unzip(dados);
                    obj = Newtonsoft.Json.JsonConvert.DeserializeObject<T>(unzipStr);
                    execucaoComSucesso = true;
                }
                catch (OutOfMemoryException)
                {
                    tentativas++;
                    if (tentativas == 3)
                        throw;
                    // Aguardar até 2 segundos para fazer o retry.
                    // Esse foi um erro de falta de memória.
                    Random r = new Random(DateTime.Now.Second);
                    Thread.Sleep(r.Next(2000));
                }
            }
            while ((!execucaoComSucesso) && (tentativas < 3));
            return obj;
        }

        public static byte[] Base64ToByte(string dados)
        {
            return Convert.FromBase64String(dados);
        }


        /// <summary>
        /// descompacta uma string
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
        public static string Unzip(byte[] bytes)
        {
            using (var msi = new MemoryStream(bytes))
            {
                using (var mso = new MemoryStream())
                {
                    using (var gs = new GZipStream(msi, CompressionMode.Decompress))
                    {
                        gs.CopyTo(mso);
                    }

                    return Encoding.UTF8.GetString(mso.ToArray());
                }
            }
        }

    }
}
